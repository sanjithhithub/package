def add_two_numbers(x, y):
    return x+y
